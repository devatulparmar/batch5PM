Wraps platform-specific persistent storage for simple data (NSUserDefaults on iOS and macOS, SharedPreferences on Android, etc.). Data may be persisted to disk asynchronously, and there is no guarantee that writes will be persisted to disk after returning, so this plugin must not be used for storing critical data. 

## Usage

To use this plugin, add locked_shared_preferences as a dependency in your pubspec.yaml file.

```dart

dependencies:
  flutter:
    sdk: flutter
  locked_shared_preferences:
  
```

## Getting Started

Import the package and initialise the instance

```dart

import 'package:locked_shared_preferences/locked_shared_preferences.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
 
  await LockedSharedPreferences.getInstance(); // initialise instance before runApp() 
  // .. 
}

```

## Examples

Here are small examples that show you how to use the API.

## Write data

```dart

// Save an integer value to 'counter' key.
LockedSharedPreferences.putInt('counter', 10);
// Save an boolean value to 'repeat' key.
LockedSharedPreferences.putBool('repeat', true);
// Save an double value to 'decimal' key.
LockedSharedPreferences.putDouble('decimal', 1.5);
// Save an String value to 'action' key.
LockedSharedPreferences.putString('action', 'Start');
// Save an list of strings to 'items' key.
LockedSharedPreferences.putStringList('items', <String>['Earth', 'Moon', 'Sun']);
   
```

## Read data

```dart

// Save an integer value to 'counter' key.
LockedSharedPreferences.getInt('counter');
// Save an boolean value to 'repeat' key.
LockedSharedPreferences.getBool('repeat');
// Save an double value to 'decimal' key.
LockedSharedPreferences.getDouble('decimal');
// Save an String value to 'action' key.
LockedSharedPreferences.getString('action');
// Save an list of strings to 'items' key.
LockedSharedPreferences.getStringList('items');
   
```

## Remove an entry

```dart
// Remove data for the 'counter' key.
LockedSharedPreferences.remove('counter');
```
